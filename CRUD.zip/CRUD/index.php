<!doctype html>
<html lang="pt-br">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
<title>Cidadão Saúde</title>
</head>
<body>
<script type="text/javascript">
 	alert("Bem vindo ao site Cidadão Saúde!!");
 
 	
 </script>
<br>
<script>
{
alert("                                       Cuide de sua Saúde!!!        \n\nPara evitar a propagação da COVID-19, faça o seguinte:\n1-Lave suas mãos com frequência.\n2-Use sabão e água ou álcool em gel.\n3-Mantenha uma distância segura de pessoas que estiverem tossindo ou espirrando.\n4-Use máscara quando não for possível manter o distanciamento físico.\n5-Não toque nos olhos, no nariz ou na boca.\n6-Cubra seu nariz e boca com o braço dobrado ou um lenço ao tossir ou expirar.\n7-Fique em casa se você se sentir indisposto.\n8-Procure atendimento médico se tiver febre, tosse e dificuldade para respirar.\n9-Ligue com antecedência para o plano ou órgão de saúde ou para o número(61) 9938-0031 e peça direcionamento à unidade mais adequada.\n10-Isso protege você e evita a propagação de vírus e outras infecções.\n\n#TodosContraOCovid-19")
}
</script>
    <br>
        <div class="container-fluid maximo">
          <div class="jumbotron">
            <div class="row ">
                <h2>Cidadão Saúde <span class="text-danger"></span></h2>
            </div>
          </div>
            </br>
            <div class="row">
                <p>
                    <a href="create.php" class="btn btn-dark">Adicionar</a>
                </p>
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Id</th>
                            <th scope="col">Nome</th>
                            <th scope="col">Endereço</th>
                            <th scope="col">Telefone</th>
                            <th scope="col">Email</th>
                            <th scope="col">Sexo</th>
                            <th scope="col">Ação</th>
                        </tr>
                    </head>
                    <body>
                        <?php
                        include 'banco.php';
                        $pdo = Banco::conectar();
                        $sql = 'SELECT * FROM pessoa ORDER BY id DESC';

                        foreach($pdo->query($sql)as $row)
                        {
                            echo '<tr>';
			                      echo '<th scope="row">'. $row['id'] . '</th>';
                            echo '<td>'. $row['nome'] . '</td>';
                            echo '<td>'. $row['endereco'] . '</td>';
                            echo '<td>'. $row['telefone'] . '</td>';
                            echo '<td>'. $row['email'] . '</td>';
                            echo '<td>'. $row['sexo'] . '</td>';
                            echo '<td width=250>';
                            echo '<a class="btn btn-primary" href="read.php?id='.$row['id'].'">Info</a>';
                            echo ' ';
                            echo '<a class="btn btn-warning" href="update.php?id='.$row['id'].'">Atualizar</a>';
                            echo ' ';
                            echo '<a class="btn btn-danger" href="delete.php?id='.$row['id'].'">Excluir</a>';
                            echo '</td>';
                            echo '</tr>';
                        }
                        Banco::desconectar();
                        ?>
<style>

body
{
    background-color:#E0EEEE !important;
}

</style>

<style>
.jumbotron {
    padding-top: 30px;
    padding-bottom: 30px;
    margin-bottom: 30px;
    color:white;
    background-color:#10111f;
}

</style>
                    </body>
                </table>
            </div>
        </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

</body>

</html>
